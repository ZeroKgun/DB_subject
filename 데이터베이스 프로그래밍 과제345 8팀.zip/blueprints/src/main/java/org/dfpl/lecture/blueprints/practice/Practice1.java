package org.dfpl.lecture.blueprints.practice;

import com.tinkerpop.blueprints.Graph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;

public class Practice1 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Graph g = new TinkerGraph();
	}
}
